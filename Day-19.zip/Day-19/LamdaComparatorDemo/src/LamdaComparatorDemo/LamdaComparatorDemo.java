package LamdaComparatorDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class employee{
	int age;
	String name;
	public employee(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}	
}
public class LamdaComparatorDemo {
	
	public static void main(String[] args) {
		ArrayList<employee> emp = new ArrayList<employee>();
		emp.add(new employee(43, "Jack"));
		emp.add(new employee(31, "Tony"));
		emp.add(new employee(21, "Stark"));
		
		
		System.out.println("Age compartor");
		Comparator<employee> Agecompare = (E1,E2) -> {
			return (E1.age == E2.age) ? 1:(E1.age > E2.age) ? 0 : -1;			
		};
		Collections.sort(emp, Agecompare);
		
		for( employee i : emp ) {
			System.out.println( i.age + " " + i.name );			
		}
		
		System.out.println("Name compartor");
		Comparator<employee> Namecompare = (E1,E2) -> {
			return E1.name.compareTo(E2.name);		
		};
		Collections.sort(emp, Namecompare);
		
		for( employee i : emp ) {
			System.out.println( i.age + " " + i.name );			
		}
	}
}

//class compare implements Comparator<employee> {
//	@Override
//	public int compare(employee o1, employee o2) {
//		employee E1 = (employee) o1;
//		employee E2 = (employee) o2;
//		
//		return 
				
//		if (E1.age == E2.age) {
//			return 1;
//		}
//		else if(E1.age > E2.age) {
//			return 0;
//		}
//		else {
//			return -1;
//		}
//	}
//}


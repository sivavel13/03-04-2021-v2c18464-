package threadLadmdaDemo;
import java.lang.Runnable;

public class threadLadmdaDemo {

	public static void main(String[] args) {
	
		Runnable R1 = () -> {
			System.out.println("First Runnable Inteface start run");
		};
		Runnable R2 = () -> {
			System.out.println("Second Runnable Inteface start run");
		};
		Thread T1 = new Thread(R1);
		Thread T2 = new Thread(R2);
		T1.start();
		try {Thread.sleep(3000);} catch(Exception e) {}
		
		T2.start();
		System.out.println(T2.isAlive());
		
		try {Thread.sleep(1000);} catch(Exception e) {}
		
		System.out.println("Thread is running ");
		
		System.out.println(T2.isAlive());
	}

}
